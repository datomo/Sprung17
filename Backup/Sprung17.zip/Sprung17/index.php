<?php defined( '_JEXEC' ) or die; 

include_once JPATH_THEMES.'/'.$this->template.'/logic.php';

?><!doctype html>

<html lang="<?php echo $this->language; ?>">

<head>
  <jdoc:include type="head" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
  <link rel="apple-touch-icon-precomposed" href="<?php echo $tpath; ?>/images/apple-touch-icon-57x57-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo $tpath; ?>/images/apple-touch-icon-72x72-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo $tpath; ?>/images/apple-touch-icon-114x114-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo $tpath; ?>/images/apple-touch-icon-144x144-precomposed.png">
</head>
  
<body class="<?php echo (($menu->getActive() == $menu->getDefault()) ? ('front') : ('site')).' '.$active->alias.' '.$pageclass; ?>">
  
  	<div id="fb-root"></div>
	<script>(function(d, s, id) {
	  var js, fjs = d.getElementsByTagName(s)[0];
	  if (d.getElementById(id)) return;
	  js = d.createElement(s); js.id = id;
	  js.src = "//connect.facebook.net/de_DE/sdk.js#xfbml=1&version=v2.8&appId=1199833370107049";
	  fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));</script>

	<jdoc:include type="modules" name="mainMenu"/>
	<div class="banner">
		<img id="background-logo" src="<?php echo $tpath; ?>/images/hintergrund.jpg" alt="Logo">
		<img id="titel-logo" src="<?php echo $tpath; ?>/images/titel.png" alt="Titel">
	</div>
	<jdoc:include type="modules" name="top" /> 
	<jdoc:include type="component" />
	<jdoc:include type="modules" name="bottom" />
	
	<div class="fb-page" data-href="https://www.facebook.com/sprungbraett/" data-tabs="timeline" data-small-header="true" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="true"><blockquote cite="https://www.facebook.com/sprungbraett/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/sprungbraett/">Sprungbrätt</a></blockquote></div>

  	<jdoc:include type="modules" name="debug" />
</body>

</html>
